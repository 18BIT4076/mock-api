# Getting Started with Create React App

## Command to run the application

1. npm i
2. npm start
3. Open [http://localhost:3000](http://localhost:3000) to view it in the browser.


## You can create an account with register and using the same credentials in login page

you can see the list of the user details on the page
